package pl.edu.pg.eti.backend.event;

public enum EventType {
    NEW_CONNECTION
}
