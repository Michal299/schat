package pl.edu.pg.eti.gui.controller;

public class MessagePaneController {
}
