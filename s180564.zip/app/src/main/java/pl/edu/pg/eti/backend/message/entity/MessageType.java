package pl.edu.pg.eti.backend.message.entity;

public enum MessageType {
    TEXT,
    FILE,
    SESSION_KEY,
    PUBLIC_KEY,
    INVITATION
}
