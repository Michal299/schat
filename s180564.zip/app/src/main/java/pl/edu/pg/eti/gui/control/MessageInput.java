package pl.edu.pg.eti.gui.control;

import javafx.scene.layout.VBox;

public class MessageInput extends VBox {
}
