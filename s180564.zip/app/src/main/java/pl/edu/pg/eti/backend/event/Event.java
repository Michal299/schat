package pl.edu.pg.eti.backend.event;

public interface Event {
    EventType getType();
}
