package pl.edu.pg.eti.gui.control;

import javafx.scene.layout.StackPane;

public class Message extends StackPane {

    public Message(String author, String content) {

    }
}
