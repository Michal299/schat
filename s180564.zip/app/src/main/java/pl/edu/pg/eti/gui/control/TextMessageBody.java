package pl.edu.pg.eti.gui.control;

public class TextMessageBody {
}
